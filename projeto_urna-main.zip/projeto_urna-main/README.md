# projeto_urna
URNA
Primeira versão  do código da urna. Há apenas duas telas, com botões e prompts.

O que fazer hj. Obrigatóriedade de preenchimento dos prompts, segunda tela clicavél e otimizar CSS.
