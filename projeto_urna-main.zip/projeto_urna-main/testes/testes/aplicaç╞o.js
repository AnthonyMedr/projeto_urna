document.addEventListener("DOMContentLoaded", function () {
    const meuFormulario = document.getElementById("meuFormulario");

    meuFormulario.addEventListener("submit", function (event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        // Validação do formulário
        const nome = document.getElementById("nome").value;
        const matricula = document.getElementById("matricula").value;

        if (nome === "" || matricula === "") {
            alert ("Por favor, preencha todos os campos.");
        } 
        else {
            // Redireciona para outra página após o preenchimento bem-sucedido
            window.location.href = "pagvotacao.html";
            
        }
    });
});
