document.addEventListener("DOMContentLoaded", function () {
    const meuFormulario = document.getElementById("meuFormulario");

    meuFormulario.addEventListener("submit", function (event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        // Validação do formulário
        const cpf = document.getElementById("cpf").value;
        const senha = document.getElementById("senha").value;

        if ( cpf === "" || senha === "") {
            alert("Por favor, preencha todos os campos.");
        } else {
            // Redireciona para outra página após o preenchimento bem-sucedido
            window.location.href = "pagvotacao.html";
        }
    });
});
