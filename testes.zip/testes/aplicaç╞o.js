
var nome = prompt("Por favor, insira seu nome:");

var matricula = prompt("Por favor, insira sua mátricula:");


alert("Olá, " + nome + "! Bem-vindo(a)!");
